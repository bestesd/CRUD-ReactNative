import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyC1PJxGHxm8QyOYS37d1EixfU9z49XfnHo",
  authDomain: "projeto-mobile-iii.firebaseapp.com",
  projectId: "projeto-mobile-iii",
  storageBucket: "projeto-mobile-iii.appspot.com",
  messagingSenderId: "831702154075",
  appId: "1:831702154075:web:5cca061bf9b2f0cbf8787e",
  measurementId: "G-GZBV8M9LMY"
};

if (!firebase.apps.length){
firebase.initializeApp(firebaseConfig)
}
export { firebase }